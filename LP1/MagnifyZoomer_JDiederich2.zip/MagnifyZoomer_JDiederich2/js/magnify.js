// jQuery Statement anatomy
// $([selector]).method([parameter(s)])

// $(document).ready(function() {});

$(function() {  // Shortcut for .ready method
	
	var nativeWidth = 0,
			nativeHeigth = 0,
			$magnifyDiv = $('.magnify');  // $('.magnify');... will be replaced with  the node list as the matched set of elements.

	
	// Only after the native dimensions of 
	// our imagea are available will our
	// script show the "zoomed" version of the image.
	//
	// Since nativeWidth & nativeHeigth start at 0
	// we need to get the image's actual dimensions
	// after it is finished downloading.
	var imageObject = new Image();  // Calling image constructor function to instantiate a new image object.
	
	imageObject.src = $('.small').attr('src');
	console.log(imageObject.src);  // Grabs a new version of the original image.  Image in HTMl is modified for size.
	
	
	// Wait until new image has finished loading...
	// Function will run after image object finished loading.
	
	// imageObject.addEventListener('load', function() {}, false);  (jQuery way)
	imageObject.onload = function() {				// Older way <img onload=" ">  imageObject is an html tag in essence.
		
		var magnifyOffset,
				mouseX,
				mouseY,
				$glass = $('.large'),
				glassWidth = $glass.width(),
				glassHeight = $glass.height(),
				$smallImage = $('.small'),
				smallImageWidth = $smallImage.width(),
				smallImageHeight = $smallImage.height(),
				backgroundX,
				backgroundY,
				posX,
				poxY;
		
		console.log('glassWidth = ' + glassWidth + '\nglassHeight = ' + glassHeight);
		
		nativeWidth = imageObject.width;
		nativeHeight = imageObject.height;
		
		console.log('imageWidth = ' + nativeWidth + '\nglassHeight = ' + nativeHeigth);
		
	// When user moves the mouse anywhere within the div.magnify
	// do the following...
		
		$magnifyDiv.mousemove(function(e) { 
			
			// 3 items needed for event listeners or event handlers.
				// Type of event
				// Object the event should occur on
				// Function to execute
			
			// Wrap the container in a jQuery object
			$target = $(this);  // this is div.magnify
			
			// Get coordinates of our container element relative
			// to the edges of the page (document)
			
			magnifyOffset = $target.offset();
			// magnifyoffset is now an object with top and left properties
			// offset returns and object with top & left properties
			
			console.log('left edge to page left edge ' + magnifyOffset.left + '\ntop edge to page top edge ' + magnifyOffset.top);
			
			// Subtract the top and left offset values to get
			// our mouse pointer location relative to the edges of 
			// div.magnify.
			mouseX = e.pageX - magnifyOffset.left;
			mouseY = e.pageY - magnifyOffset.top;
			
			console.log('mouse position to image left edge = ' + mouseX + '\nmouse position to page top edge ' + mouseY);
			
			// Fade in the magnifying glass if the mouse is inside of 
			// div.magnify and fade it out when it leaves div.magnify.
			
			$glass.stop().fadeIn(100);
			
			// Make the magnifying glass div.large follow the mouse
			// pointer.
			//
			// Do calculations to "zoom" to the correct part of the
			// larger image (background image) that correspondes 
			// to where the mouse pointer is.
		
			posX = mouseX - glassWidth/2;
			posY = mouseY - glassHeight/2;
			
			backgroundX = Math.round(mouseX / smallImageWidth * nativeWidth - glassWidth/2) * -1;
			
			backgroundY = Math.round(mouseY / smallImageHeight * nativeHeight - glassHeight/2) * -1;
			
			
			$glass.css({  // Pass css property you want to change and then its value. 
				top: posY,
				left: posX,
				backgroundPosition: backgroundX + 'px ' + backgroundY + 'px'
			});  
			
			
			// Fade out magnifying glass when mouse leaves div.magnify
			// based on edge values...
			if (mouseX < 0 || mouseX > smallImageWidth) {
				$glass.stop().fadeOut(100);
				
			} else if (mouseY < 0 || mouseY > smallImageHeight) {
					$glass.stop().fadeOut(100);
				}
			
			
		});
		
	};
	
});

