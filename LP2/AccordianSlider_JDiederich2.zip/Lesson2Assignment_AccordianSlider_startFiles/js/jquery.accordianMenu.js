/* First part of all plugins
	;(function($, window, undefined) {})(jQuery, window); 
	** Anomyous function definition  */

;(function($, window, undefined) {
	
	'use strict';
	
	// Constructor function for our plugin object
	$.AccordianMenu = function(options, selectedDOMElement) {
		
		// this is the new object
		// always assign passed in paramater as a property of the object to use them later. Parameter is only local. objects are global to class.
		this.$menuDiv = $(selectedDOMElement);
		this._init(options);
		
	};
	
	
	// Set up properties and methods of our new plugin objects "class"
	$.AccordianMenu.defaults = {
		speed: '250',
		easing: 'ease',
		defaultItem: 0,
		menuWidth: '415px',
		sliceWidth: '90px'
		
	};
	
	
	$.AccordianMenu.prototype = {
		
		_init: function(options) {
			
			this.options = $.extend(true, $.AccordianMenu.defaults, options);
		
			// 'ul tags of $subMenu
			this.$menu = this.$menuDiv.children('ul');
			
			// 'li' tags of $menu slice
			this.$menuItems = this.$menu.children('li');
			
			// 'a' tags of $menuItems
			this.$imgWrapper = this.$menuItems.children('a');
			
			// all children of 'a' tags with class of menuPreview
			this.$menuItemsPreview = this.$imgWrapper.children('.menuPreview');
			
			this.totalItems = this.$menuItems.length;
			
			this.currentIndex = -1;

			this._clickHandler();
			
			this._openItem(this.options.defaultItem);
			
		},
		

		_validCurrent: function() {
			return this.currentIndex >= 0 && this.currentIndex < this.totalItems;
		},
		
		
		// Represents index of menu items that should be open on page load
		_openItem: function(openedIndex) {
			this.$imgWrapper.eq(openedIndex).click();
		},
		
		
		_clickHandler: function() {
			
			var self = this;
			
			this.$imgWrapper.click(function() {
				
				var $parentLI = $(this).parent();
				
				var clickedIndex = $parentLI.index();
				
				if (self.currentIndex === clickedIndex) {
					
					self._slideItem($parentLI, false, 1500, 'easeOutQuint', true);
					
					self.currentIndex = -1;
					
				} else {
					
					if (self._validCurrent()) {
						
						self._slideItem(self.$menuItems.eq(self.currentIndex), false, 250, 'jswing');
						
						}
						
						self.currentIndex = clickedIndex;
						
						self._slideItem($parentLI, true, 250, 'jswing');

				}

				false;

			});
		
		},
		
		
		_slideItem: function($panelSlice, state, speed, easing, allClosed) {
			
			var $colorImage = $panelSlice.find('.menuImage');
			
			var bwOption;
			var colorOption;
			
			if (state) {
				
				bwOption = {width: this.options.menuWidth};
				colorOption = {left: '0px'};
				
			} else {
				
				bwOption = {width: this.options.sliceWidth};
				colorOption = {left: this.options.sliceWidth};
				
			}
			
			if (state) {
				
				this.$menuItemsPreview.stop().animate({opacity: 0.1}, 1000);
				
			} else if (allClosed) {

				this.$menuItemsPreview.stop().animate({opacity: 1}, 1500);
				
			}
			
			$panelSlice.stop().animate(bwOption, speed, easing);
			$colorImage.stop().animate(colorOption, speed, easing);
			
			if (state) {
				
				$colorImage.animate({opacity: 1}, 2000);
				
			} else {
				
				$colorImage.stop(true, true).animate({opacity: 0.2});
				
			}

		}
			
	};
	
	// Define our plugin method (function)
	$.fn.accordianMenu = function(options) {
		
		if (typeof options === 'string') {

		 } else {  

				this.each(function() {

					var instance = $.data(this, 'accordianMenu');

					if (instance) {
							instance._init();

					} else {

						instance = $.data(this, 'accordianMenu', new $.AccordianMenu(options, this));

					}

				});

		}

			return this; 
	};
	
	
})(jQuery, window);

