/* First part of all plugins
	;(function($, window, undefined) {})(jQuery, window); 
	** Anomyous function definition  */

;(function($, window, undefined) {
	
	'use strict';
	
	// Constructor function for our plugin object
	$.AccordianMenu = function(options, selectedDOMElement) {
		
		// this is the new object
		// always assign passed in paramater as a property of the object to use them later. Parameter is only local. objects are global to class.
		this.$menuDiv = $(selectedDOMElement);
		this._init(options);
		
	};
	
	// Set up properties and methods of our new plugin objects "class"
	$.AccordianMenu.defaults = {
		speed: '250',
		easing: 'ease',
		defaultitem: '0',
		menuWidth: '415px',
		sliceWidth: '90px'
		
	};
	
	$.AccordianMenu.prototype = {
		
		_init: function(options) {
			
			this.mergedOptions = $.extend($.AccordianMenu.defaults, options);
			
			this._config();
			
			this._openItem();
			
			this._clickHandler();
			
		},
		
		_config: function() {
			// 'ul tags of $subMenu
			this.$menu = this.$menuDiv.children();
			
			console.log('# of ul elements ' + this.$menu);
			
			// 'li' tags of $menu
			this.$menuItems = this.$menu.children();
			console.log(this.$menuItems.length);
			
			// 'a' tags of $menu
			this.$imgWrapper = this.$menuItems.children();
			
			// all children of 'a' tags with class of menuPreview
			this.$menuItemsPreview = this.$imgWrapper.children('menuPreview');
			
			var totalItems = this.$menuItems.length;
			
			var currentIndex = -1;
		},
		
		
		_validCurrent: function() {
			this.currentIndex = (this.currentIndex > 0 && this.currentIndex < this.totalItems - 1) ? 1 : 0;
		},
		
		
		// Represents index of menu items that should be open on page load
		_openItem: function(openedIndex) {
			this.$imgWrapper.eq().accordianMenu().trigger();
		},
		
		
		_clickHandler: function() {
			
			var self = this;
			
			this.$imgWrapper.click(function() {
				
				this.$parentLI = $(this).parent();
				
				this.clickedIndex = this.$parentLI.index(this.$menuItems);
				console.log(this.clickedIndex);
				
				if (this.currentIndex === this.clickedIndex) {
					
					this._slideItem(this.$parentLI).css({
						state: 'false',
						speed: '1500ms',
						easing: 'easeOutQuad',
						allClosed: 'true'
					});
					
					this.currentIndex = -1;
					
				} else {
					
					
					
				};
				
				})
		
			},
		
		
		_slideItem: function($panelSlice, state, speed, easing, allClosed) {
			
			
		}
			
	};
	
	// Define our plugin method (function)
	
	$.fn.accordianMenu = function(options) {
		
		  if (typeof options === 'string') {
            
            // not as common, leave off code for now...
            // the above condition is almost never true...
       }
       else {  // options !== 'string', usually meaning it is an object
            
            // here, this refers to the jQuery object that was used
            // to call this plugin method ($('#quoteRotator'))
            this.each(function() {
                
								// here inside our each function, the context of this has changed and it now refers to the current matched element (DOM Element) that "each" is iterating over now.
							
								// In our case, this refers to div#quoteRotator
							
								// below says check the DOM element (div#accordianMenu) see if it has a variable (named data store) named accordianMenu
                var instance = $.data(this, 'accordianMenu');
                
                if (instance) {
                    instance._init();
                } else {
                  
									// .data() setter mode
									
									// new something is creating an object
									instance = $.data(this, 'accordianMenu', new $.AccordianMenu(options, this));
                    
                    
                }
                
            });
            
        }
		
				return this;  // Returns the value of this which is now accordianMenu function  reurning the jquery object the method was called on.
		
				// *** importan *** makes the object chainable  makes accordianMenu method chainable
	};
	
	
})(jQuery, window);

