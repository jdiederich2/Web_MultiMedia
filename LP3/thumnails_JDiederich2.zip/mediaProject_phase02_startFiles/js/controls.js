function initializePlayer() {
	
	// Get a reference to our video
	video = document.querySelector('video.shadowEffect');
	
	// Turn off defaul controls on video
	video.controls = false;
	
	// Select the video cover image and wrap in jquery object
	$videoCover = $('#videoCover');
	
	var seconds;
	
	
	
	//
	// Grab handles (nicknames or references) to our 
	// various control elements (tags)
	//
	playPauseButton = document.querySelector('#playPause');
	stopButton = document.querySelector('#stopButton');
	progressBar = document.querySelector('#progressBar');
	playProgress = document.querySelector('#played');
	muteButton = document.querySelector('#mute');
	volumeSlider = document.querySelector('#volumeSlider');
	fullScreenButton = document.querySelector('#fullScreen');
	thumbnail = document.querySelector('.thumb');
	
	// Update the progressBar and currentTime as video plays 
	video.addEventListener('timeupdate', updateProgress, false);
	
	// Add "seek" capability
	progressBar.addEventListener('mouseup', function(e) {
		
		// If user clicks on progressBar before video has begun playback
		// simply fadeout the cover image.
		
		if (!video.currentTime) {
			togglePlay();
			
			playPauseButton.className = 'pauseBtn';
		}
		
		// e.pagex and e.pageY are the x,y coordinates where the 
		// mouse event occured relative to the edges of the page.
		//
		// e.offsetX and e.offsetY are the x,y coordinates where
		// the mouse event occured relative to the target element -
		// the element the event occured on.
		// also the know as "this"
		//
		
		var playPosition = e.offsetX.toFixed(2);
		
		video.currentTime = ((video.duration / progressBar.offsetWidth) * playPosition).toFixed(2);
		
	}, false);
		// e is the event as an opject... ours is mouseup object
		// Somethings like this in lesson 3 assignment
	
	
	// Fade the cover image back in when the video ends naturally
	video.addEventListener('ended', function() {
		
		if (playPauseButton.className = 'pauseBtn') {
			playPauseButton.className = 'playBtn'
		}
		
		$videoCover.fadeIn(3000);
		
	}, false);
	
	progressBar.addEventListener('mouseenter', function(e) {
		
		thumbnail.style.display = 'block';
		
	}, false);
	
	progressBar.addEventListener('mouseleave', function(e) {
		
		thumbnail.style.display = 'none';
		
	}, false);
	
	progressBar.addEventListener('mousemove', function(e) {
		
		 var mousePos = e.offsetX  * (video.duration / progressBar.offsetWidth);
		
		 var cuesList = video.textTracks[0].cues;
		
			for (var i=0; i<cuesList.length; i++) {
				if(cuesList[i].startTime <= mousePos && cuesList[i].endTime > mousePos) {
					
						break;
	
				};
				
				thumbnail.style.backgroundSize = '120px';
				thumbnail.style.backgroundImage = 'url(' + cuesList[i].text + ')';
				thumbnail.style.left = (e.offsetX - 35 + 'px');
				thumbnail.style.top = 530 + 'px';

			};	
			
	});
				

	
	lastVolumeSetting = volumeSlider.value;
	
	// Time Values
	currentTimeText = document.querySelector('#currentTime')
	durationTimeText = document.querySelector('#durationTime')
	
	// Determine and display duration time
	durationMinutes = Math.floor(video.duration / 60);
	durationSeconds = Math.floor(video.duration % 60);
	
	if (durationSeconds < 10) {
		seconds = "0" + durationSeconds;
	} else {
		seconds = durationSeconds;
	}
	
	durationTimeText.innerHTML = durationMinutes + ":" + seconds;
	
	//
	// Add event listeners to detect when a control has been
	// activated by the user
	//
	playPauseButton.addEventListener('click', togglePlay, false);
	stopButton.addEventListener('click', stopVideo, false);
	muteButton.addEventListener('click', toggleMute, false);
	fullScreenButton.addEventListener('click', fullScreen, false);
	volumeSlider.addEventListener('input', setVolume, false);
	
}

function togglePlay(){
	
	/* if video is paused or ended, 
				then play
				if video cover is showing, 
					remove it...
				change icon to pause
				
			else if playing, 
				then pause	
				change icon to playPauseButton
	*/
	
	if (video.paused || video.ended) {
		
		if($videoCover) {
			
			 $videoCover.stop(true).fadeOut(500);
			
		}
		
		video.play();
		
		// Change icon to pause
		this.className = 'pauseBtn';
		
		
	} else { // Video playing
		
		video.pause();
		this.className = 'playBtn';
		
	}
	
}


function stopVideo() {
		
		video.pause();
		
		// Reset video playback to the beginning
		video.currentTime = 0;
		
		if (playPauseButton.className == 'pauseBtn') {
			playPauseButton.className = 'playBtn';
		}
}

function toggleMute() {

	
	if (video.muted) {
			
			volumeSlider.value = lastVolumeSetting;
			
			video.muted = false;
			muteButton.className = 'mute';
	
			} else {
				
				lastVolumeSetting = volumeSlider.value;
				volumeSlider.value = 0;
				video.muted = true;
				muteButton.className = 'unMute';
				
			}
}


function fullScreen() {
	
	// User feature to determine if the users browser supports 
	// requestFullScreen()
	if	(video.requestFullScreen) {
			video.requestFullScreen();
		
	} else if (video.webkitRequestFullScreen) {
			video.webkitRequestFullScreen();
		
	} else if (video.mozRequestFullScreen) {
			video.mozRequestFullScreen();
		
	} else if (video.msRequestFullScreen) {
			video.allowFullScreen = true;
			video.msRequestFullScreen();
		
	}
	
}


function setVolume() {
	
	video.volume = this.value;
	
	if(video.muted) {
		toggleMute();
		
	} else if (!video.volume) {
		toggleMute();
	}
	
}


function updateProgress() {
	
	var value = 0;
	
	if (video.currentTime > 0) { // Not at beginning of video
		
		// Get percentage that reflects current playback progress of the 
		// video. Store as percentage.
		
		value = (100 / video.duration) * video.currentTime;
		
	}
	
	// fill the progress bar (its span child) to the point
	// where the video playback is at, based on its percentage
	playProgress.style.width = value + '%';
	
	// Determine and display current time
	currentMinutes = Math.floor(video.currentTime / 60);
	currentSeconds = Math.floor(video.currentTime % 60);
	
	if (currentSeconds < 10) {
		seconds = "0" + currentSeconds;
	} else {
		seconds = currentSeconds;
	}
	
	currentTimeText.innerHTML = currentMinutes + ':' + seconds;
	
	
}




























