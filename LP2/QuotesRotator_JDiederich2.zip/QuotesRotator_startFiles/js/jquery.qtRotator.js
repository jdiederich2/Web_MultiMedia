/* First part of all plugins
	;(function($, window, undefined) {})(jQuery, window); 
	** Anomyous function definition  */

;(function($, window, undefined) {
	
	'use strict';
	
	var Modernizr = window.Modernizr;
	
	// Constructor function for our plugin object
	$.QTRotator = function(options, selectedDOMElement) {
		
		// this is the new object
		// always assign passed in paramater as a property of the object to use them later. Parameter is only local. objects are global to class.
		this.$selectedElement = $(selectedDOMElement);
		this._init(options);
		
	};
	
	
	
	// Set up properties and methods of our new plugin objects "class"
	
	// Set up what is called the default property
	// This here would represent the generic object which is useless
	
	$.QTRotator.defaults = {
		speed: 700,
		easing: 'ease',
		interval: 8000
	};
	
	
	
	// Object's method definition via the prootype property
	
	// Could have done this for _init()
	//
	// $.QTRotator._init = function(options) {};
	// 
	// Decide prototype way... if you don't use prototype and then 
	// instantiate the object multiple time, it will store all copies of them // in memory. If you use prototype it only stores once copy of the 
	// method.
	$.QTRotator.prototype = {
		
		_init: function(options) {
				// inside context method of object
				// mergedOptions property will merge with passed in properties. Passed in wins.
				// Last option will win
				this.mergedOptions = $.extend($.QTRotator.defaults, options);
			
				// Need to set other properties... could set them all here, but 
				// instead going to use another method to configure properties
			
				this._config(); // set more properties on our new object, this is a function call for below function.
			
				// show current quote set by currentIndex below
				this.$items.eq(this.currentIndex).addClass('quoteCurrent');
			
				if (this.support) {
					this._setTrnsition();
				}
			
				// Start rotating the quotes
				this._startRotator();
				
			
		},
		
		
		_config: function() {
			
				this.$items = $('.quoteContent');
				// $items is now a jquery object of ALL elements with class 
				// quoteContent
				console.log("# of .quoteContent divs = # " + this.$items.length);
			
				// Property
				this.itemsCount = this.$items.length;
			
				// Property
				this.currentIndex = 0;
			
				// Taking csstransitions as property of support value will either be true or false
				this.support = Modernizr.csstransitions;	
			
				if (this.support) {
					
					// Can pass html as a selector for Jquery. Cretes that tag
					// Same as add element
					//
					// appendTo() adds to dom as last child 
					// going into the jquery obj (this.$selectedElement) matched set of elements
					this.$progressBar = $('<span class = "quoteProgress"></span>').appendTo(this.$selectedElement);
					
				} else {
					// do some alternative tasks here...
				}
		},
		
		
		_setTrnsition: function() {
			
			// calling method called proxy and calling function as it's param.
			// proxy second param is context refers to 'this' inside the function
			// this is alway based on context. "this" still now refers to QTRotator object.
			// Settimeout function normally changes this to something else. Adding this as 
			// 'context' param makes sure "this" stays the same.
			setTimeout($.proxy(function() {
				
				// Set transistion for opacity on every quoteContent div
				this.$items.css('transition', 'opacity ' + this.mergedOptions.speed + 'ms ' + this.mergedOptions.easing);
				
			}, this), 25);
			
		},
		
		
		_startRotator: function() {
			
			// Animate the width of the progress bar from 0% to 100% overtime
			if (this.support) {
				
				this._startProgress();
				
			} else {
				// Tasks to do later
				
			}
			
			// Reset the progress bar and animate in the next quote
			setTimeout($.proxy(function() {
				
				// Reset progressBar
				if(this.support) {
					this._resetProgressBar();
					
				}
				
				// bring in next quote...
				this._nextQuote();
				
				// Loops through the pictures using recursive function call, meaning
				// this functions code calls itself.
				this._startRotator();
				
			}, this), this.mergedOptions.interval + 25);
			
		},
		
		
		_startProgress: function() {
		
			setTimeout($.proxy(function() {
		
				this.$progressBar.css({
					transition: 'width ' + this.mergedOptions.interval + 'ms linear',
					width: '100%'
					
				});
		
			}, this), 25);
	
		},
		
		
		_resetProgressBar: function() {
			
			this.$progressBar.css({
				transition: 'none',
				width: '0%'
			});
			
		},
		
		
		_nextQuote: function() {
			
			// hide the currently showing quote by removing quotecurrentClass
			this.$items.eq(this.currentIndex).removeClass('quoteCurrent');
			
			// update the index, get the index of the next quote (div.quoteContent)
			// ternary operator:
			//		identifier = condition ? then code : else code;
			this.currentIndex = this.currentIndex < this.itemsCount - 1 ? this.currentIndex + 1 : 0;
			
			// could have used: 
			// if (this.currentIndex < this.itemsCount -1) {
			//				this.currentIndex += 1;
			 
			// } else {
			// this.currentIndex = 0
		
			// this.currentIndex += 1;
			
			// show the next quote
			this.$items.eq(this.currentIndex).addClass('quoteCurrent');
			
			}
			
		
			
		
	};
	
	
	
	// Define our plugin method (function)
	
	$.fn.qtRotator = function(options) {
		
		  if (typeof options === 'string') {
            
            // not as common, leave off code for now...
            // the above condition is almost never true...
       }
       else {  // options !== 'string', usually meaning it is an object
            
            // here, this refers to the jQuery object that was used
            // to call this plugin method ($('#quoteRotator'))
            this.each(function() {
                
								// here inside our each function, the context of this has changed and it now refers to the current matched element (DOM Element) that "each" is iterating over now.
							
								// In our case, this refers to div#quoteRotator
							
								// below says check the DOM element (div#qtRotator) see if it has a variable (named data store) named qtRotator
                var instance = $.data(this, 'qtRotator');
                
                if (instance) {
                    instance._init();
                } else {
                  
									// .data() setter mode
									
									// new something is creating an object
									instance = $.data(this, 'qtRotator', new $.QTRotator(options, this));
									
									
                    
                    
                }
                
            });
            
        }
		
				return this;  // Returns the value of this which is now qtRotator function  reurning the jquery object the method was called on.
		
				// *** importan *** makes the object chainable  makes qtRotator method chainable
	};
	
	
})(jQuery, window);

