$(function () {

			// HTML line 75

			var $pTextDropText = $('p.textDrop');
			var $dustPuffsDiv = $('#dustPuffs');
			var $dustPuffs = $('.dustPuffs');


			$pTextDropText.css({
				transform: 'scale(8, 18)',
				opacity: '0.2',
				top: '-150px'
				
			}).animate({
				
				transform: 'none',
				opacity: '0.8',
				top: '0'
				
			}, 1000, 'easeInExpo', function () {

				$dustPuffsDiv.show()
				
				});

				$dustPuffs.each(function () {

					$(this).animate({
						opacity: '0.2',
						transform: 'scale(3, 2)'
						
					}, 1500)

				}).promise().done(function () {
					$dustPuffsDiv.fadeOut(800, function () {
						$dustPuffs.css({
							opacity: 1,
							transform: 'scale(1, 1)',
							
						});

					})

					$pTextDropText.animate({
						left: '-200px'
					}, 500, 'easeOutElastic');

				})

			}).animate({
				transform: 'scale(1.0015, 1.0015)'
			}).animate({
				transform: 'scale(1, 1)'

			});


